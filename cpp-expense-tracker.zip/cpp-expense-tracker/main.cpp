#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <iomanip>
#include <map>

using namespace std;

struct Expense {
    string date; // Format: YYYY-MM-DD
    string category;
    string description;
    double amount;
};

class ExpenseTracker {
private:
    vector<Expense> expenses;

public:
    void addExpense() {
        Expense e;
        cout << "Enter date (YYYY-MM-DD): ";
        cin >> e.date;
        cout << "Enter category: ";
        cin >> e.category;
        cin.ignore();
        cout << "Enter description: ";
        getline(cin, e.description);
        cout << "Enter amount: ";
        cin >> e.amount;
        expenses.push_back(e);
        cout << "Expense added successfully.\n";
    }

    void viewExpenses() {
        if (expenses.empty()) {
            cout << "No expenses recorded.\n";
            return;
        }
        cout << left << setw(12) << "Date" << setw(15) << "Category" << setw(30) << "Description" << "Amount" << endl;
        cout << string(70, '-') << endl;
        for (const auto& e : expenses) {
            cout << left << setw(12) << e.date << setw(15) << e.category << setw(30) << e.description << e.amount << endl;
        }
    }

    void deleteExpense() {
        viewExpenses();
        if (expenses.empty()) return;

        int index;
        cout << "Enter the index (starting from 1) of the expense to delete: ";
        cin >> index;
        if (index < 1 || index > expenses.size()) {
            cout << "Invalid index.\n";
            return;
        }
        expenses.erase(expenses.begin() + index - 1);
        cout << "Expense deleted.\n";
    }

    void saveToFile(const string& filename) {
        ofstream out(filename);
        for (const auto& e : expenses) {
            out << e.date << ',' << e.category << ',' << e.description << ',' << e.amount << '\n';
        }
        out.close();
        cout << "Data saved to file.\n";
    }

    void loadFromFile(const string& filename) {
        ifstream in(filename);
        if (!in) return; // no file to load
        expenses.clear();
        string line;
        while (getline(in, line)) {
            Expense e;
            size_t pos1 = line.find(',');
            size_t pos2 = line.find(',', pos1 + 1);
            size_t pos3 = line.find(',', pos2 + 1);
            e.date = line.substr(0, pos1);
            e.category = line.substr(pos1 + 1, pos2 - pos1 - 1);
            e.description = line.substr(pos2 + 1, pos3 - pos2 - 1);
            e.amount = stod(line.substr(pos3 + 1));
            expenses.push_back(e);
        }
        in.close();
        cout << "Data loaded from file.\n";
    }

    void reportByCategory() {
        map<string, double> categoryTotals;
        for (const auto& e : expenses) {
            categoryTotals[e.category] += e.amount;
        }
        cout << "\nExpense Summary by Category:\n";
        for (const auto& pair : categoryTotals) {
            cout << left << setw(15) << pair.first << ": $" << pair.second << endl;
        }
    }
};

int main() {
    ExpenseTracker tracker;
    tracker.loadFromFile("expenses.csv");

    int choice;
    do {
        cout << "\nExpense Tracker Menu:\n";
        cout << "1. Add Expense\n";
        cout << "2. View All Expenses\n";
        cout << "3. Delete Expense\n";
        cout << "4. View Report by Category\n";
        cout << "5. Save and Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: tracker.addExpense(); break;
            case 2: tracker.viewExpenses(); break;
            case 3: tracker.deleteExpense(); break;
            case 4: tracker.reportByCategory(); break;
            case 5: tracker.saveToFile("expenses.csv"); break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 5);

    return 0;
}
